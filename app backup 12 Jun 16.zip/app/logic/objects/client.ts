import {Person} from './person';

export class Client {
	person: Person
	
	constructor () {
		this.person = new Person("","","","","","","","","","","");
	}
}