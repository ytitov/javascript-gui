import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';

import {Employee} from "../../logic/objects/employee"
import {UserGuiDTO} from '../../logic/objects/gui-dto/UserDTO';

import {StorageService} from '../../services/Storage.service';
import {UserService} from '../../services/User.service';

@Component({
  selector: 'person-edit-component',
  templateUrl: './views/ManageDialog/PersonEdit.html',
  styleUrls: ['./views/Dialog/Dialog.css'],
  directives: [], //
  providers: [] // register the service with the injector
})

export class PersonEditComponent implements OnInit {

	@Input() canEditFields: boolean;

	// fields
	@Input() userId: string;
	@Input() phone: string;
	@Output() phoneChange: EventEmitter<string> = new EventEmitter();
	@Input() firstName: string;
	@Output() firstNameChange: EventEmitter<string> = new EventEmitter();
	@Input() lastName: string;
	@Output() lastNameChange: EventEmitter<string> = new EventEmitter();
	@Input() address1: string;
	@Output() address1Change: EventEmitter<string> = new EventEmitter();
	@Input() address2: string;
	@Output() address2Change: EventEmitter<string> = new EventEmitter();
	@Input() city: string;
	@Output() cityChange: EventEmitter<string> = new EventEmitter();
	@Input() state: string;
	@Output() stateChange: EventEmitter<string> = new EventEmitter();
	@Input() zip: string;
	@Output() zipChange: EventEmitter<string> = new EventEmitter();
	@Input() email: string;
	@Output() emailChange: EventEmitter<string> = new EventEmitter();


	constructor(
		private userService: UserService,
		private storageService: StorageService) {
			this.canEditFields = true;
	}

	ngOnInit() {

	}
	
	phoneChanged() {
		this.phoneChange.emit(this.phone);
	}
	
	firstNameChanged() {
		this.firstNameChange.emit(this.firstName);
	}
	
	lastNameChanged() {
		this.lastNameChange.emit(this.lastName);
	}
	
	address1Changed() {
		this.address1Change.emit(this.address1);
	}
	
	address2Changed() {
		this.address2Change.emit(this.address2);
	}
	
	cityChanged() {
		this.cityChange.emit(this.city);
	}
	
	stateChanged() {
		this.stateChange.emit(this.state);
	}
	
	zipChanged() {
		this.zipChange.emit(this.zip);
	}
	
	emailChanged() {
		this.emailChange.emit(this.email);
	}

}