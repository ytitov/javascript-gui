import {bootstrap} from 'angular2/platform/browser';
import {Component, OnInit} from 'angular2/core';
import {NgFor} from 'angular2/common';

import {UserGuiDTO} from './logic/objects/gui-dto/UserDTO'
import {Appointment} from './logic/objects/appointment';
import {Employee} from './logic/objects/employee';
import {ColumnItem} from './logic/calendar/columnitem';
import {RecordDTO} from "./logic/Data/RecordDTO";

// services
import {CalendarService} from './services/CalendarService';
import {UserService} from './services/User.service';
import {AppointmentService} from './services/Appointment.service';
import {StorageService} from './services/Storage.service';


// components
import {MainCalendarViewComponent}
from './views/CalendarView/MainCalendarView.component';
import {IncrementButtonComponent}
from './views/IncrementButton/IncrementButton.component';

// popup dialogs
import {AddAppointmentComponent}
from './views/AddAppointmentView/AddAppointmentView.component';
import {AddEmployeeComponent}
from './views/AddEmployee/AddEmployee.component';

// menus
import {CalendarMenuComponent}
from './views/Menus/CalendarMenu/CalendarMenu.component';



@Component({
  selector: 'app',
  templateUrl: './views/main/mainView.html',
  styleUrls: ['./views/Menus/menu.css'],
  directives: [
    AddAppointmentComponent,
    AddEmployeeComponent,
    MainCalendarViewComponent,
    IncrementButtonComponent,
    CalendarMenuComponent,
  ], //
  providers: [
    StorageService,
    UserService,
    AppointmentService,
    CalendarService,
  ] // register the services with the injector
})

export class App implements OnInit {

  displayedAppointmentList: ColumnItem[]; // this is what is fed into the calendar by
  // the service
  selectedDate: any;
  selectedEmployee: UserGuiDTO;
  showAddAppointment: boolean;
  showAddEmployee: boolean;
  showCalendarMenu: boolean;

  // testing callbacks
  public callbackFunc: Function;

  constructor(
    private storageService: StorageService,
    private calendarService: CalendarService,
    private userService: UserService,
    private appointmentService: AppointmentService) {

    this.callbackFunc = this.start.bind(this);

    // load users, start is called after users are loaded.
    this.storageService.loadAllUsersTEMP(this.callbackFunc);


    this.displayedAppointmentList = [];
    var date1 = new Date(2016, 5, 21, 0, 0, 0, 0);
    // create the calendar with date1 and 5 days
    // this.calendarService.init(date1, 3);

    this.calendarService.init();
    this.calendarService.setDate(new Date(Date.now()));
    this.calendarService.updateView();

    this.selectedDate = {
      day: "0", month: "nevermonth", year: "neveryear"
    }
    this.selectedEmployee = this.userService.getSelectedUser();

    this.showAddAppointment = false;
    this.showAddEmployee = false;
    this.showCalendarMenu = true;



    /**
     * TESTING THE STORAGE
     */
    // this.storageService.localStorage.debugONLY_delAll();
    var name = new Date(Date.now()).toDateString() + " name";
    var record = new Employee();
    record.person.first = name;
    //this.storageService.addRecord (record);

  }

  /**
   * called after, initial data is loaded, like the employee list
   */
  start(): void {
    console.log("start:");
    console.log(this.storageService.employeeList);
    // this.userService.userList = this.storageService.employeeList;
    this.calendarService.init();
    this.calendarService.updateView();
  }

  /*
  these three are called by the mainCalendarComponent
  This function updates the current date, then opens the dialog for appointment
  creation
  */

  mainCalendarComponentTimeSelected(data: any) {
    if (this.calendarService.creatingAppointment) {
      this.showAddAppointment = true; // shows the appointment dialog
      this.calendarService.creatingAppointment = false;
    }
  }

  mainCalendarComponentDateUpdate(data: any) {
    console.log("mainCalendarComponentDateUpdate");
    this.selectedDate = {
      day: data.date.getDate(),
      month: data.date.getMonth(),
      year: data.date.getFullYear()
    }
    // then tell the view to show dialog:
    // 
  }

  mainCalendarComponentEmployeeUpdate(emp: UserGuiDTO) {
    console.log("appt.ts: handleSelectedEmployee");
    this.selectedEmployee = emp;
  }


  /*
  Called from the CalendarMenu
  */
  handleNewAppointmentClick(params: any) {
    console.log(" remove this function ")
  }

  /**
   * called from the AddAppointmentView component after ok button is pressed
   */
  handleAddAppointment(item: any) {

    var appt = new Appointment(item.startDate, item.endDate);
    // appt.userId = this.userService.currentUser.getId();
    // console.log (this.calendarService);
    appt.userId = this.userService.getSelectedUser().getId();
    this.appointmentService.addAppointment(appt);
    this.calendarService.updateView();
    this.showAddAppointment = false;
  }

  handleAddEmployeeClicked() {
    this.showAddEmployee = true;
  }

  /**
   * called by multiple dialogs
   */
  handleAddRecord(record: RecordDTO) {
    this.storageService.addRecord(record);
  }


}
// bootstrap it to make it global to the whole app
bootstrap(App);