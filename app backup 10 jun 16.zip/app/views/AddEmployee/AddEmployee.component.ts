import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';

import {Employee} from "../../logic/objects/employee"

import {StorageService} from '../../services/Storage.service';
import {UserService} from '../../services/User.service';

@Component({
  selector: 'add-employee-component',
  templateUrl: './views/AddEmployee/AddEmployee.html',
  styleUrls: ['./views/Dialog.css'],
  directives: [], //
  providers: [] // register the service with the injector
})

export class AddEmployeeComponent implements OnInit {
	
	@Output() newEmployeeOutput = new EventEmitter();
	@Input() lastName: string;
	@Input() firstName: string;
	
	
	constructor (private userService: UserService) {
		console.log ("initializing AddEmployeeComponent");
		console.log(userService.userList);
	}
	
	ngOnInit () {
		
	}
	
	onAdd() {
		
	}
}