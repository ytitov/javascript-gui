import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core'; 

@Component ({
	selector: 'increment-button',
	templateUrl: './views/IncrementButton/incrementButton.html',
	directives: [],
	providers: [],
	styleUrls: ['./views/IncrementButton/incrementButton.css'],
})

export class IncrementButtonComponent implements OnInit {
	object: any; // the attached object. ie date or something
	
	@Input () titleLabel: string;
	@Input () isSelected: boolean;
	@Output() plusClicked = new EventEmitter();
	@Output() minusClicked = new EventEmitter();
	@Output() clicked = new EventEmitter();
	
	onInit () {
		
	}
	
	constructor () {
	}
	
	public onPlusClicked () {
		this.plusClicked.next('');
	}
	
	public onMinusClicked () {
		this.minusClicked.next('');
	}
	
	public onClicked () {
		this.clicked.next(this.object);
	}
}