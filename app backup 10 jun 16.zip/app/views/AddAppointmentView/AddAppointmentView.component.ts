import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';

import {UserGuiDTO} from '../../logic/objects/gui-dto/UserDTO';

import {CalendarService} from '../../services/CalendarService';
import {UserService} from '../../services/User.service';

import {IncrementButtonComponent} from '../IncrementButton/incrementButton.component';
// import {PopupDialog} from '../Dialog/Dialog.component';

@Component({
  selector: 'add-appointment-view-component',
  templateUrl: './views/AddAppointmentView/AddAppointmentView.html',
  styleUrls: ['./views/Dialog.css'],
  directives: [IncrementButtonComponent], //
  providers: [] // register the service with the injector
})

export class AddAppointmentComponent implements OnInit {

	@Output() newApptOutput = new EventEmitter();

	@Input() startHr: number;
	@Input() startMin: number;
	@Input() endHr: number;
	@Input() endMin: number;

	@Input() date: Date;
	@Input() employee: UserGuiDTO;

	constructor(private calendarService: CalendarService,
		private userService: UserService) {
		 }

	ngOnInit() {

	}

	// called from the html template
	onAdd() {
		var startDate = new Date(this.date.getFullYear(),
			this.date.getMonth(), this.date.getDate(),
			this.startHr, this.startMin, 0);
		var endDate = new Date(this.date.getFullYear(),
			this.date.getMonth(), this.date.getDate(),
			this.endHr, this.endMin, 0)
		var appt = { startDate: startDate, endDate: endDate };

		console.log("adding appointment: ")
		console.log(appt);
		this.newApptOutput.next(appt);
	}
}