import {RecordLoaderDAO} from "../RecordLoaderDAO";
import {RecordDTO} from "../RecordDTO";
import {DataBaseInfo} from "../DataBaseInfo";
import {EmployeeLoader} from "./EmployeeLoader";

declare var require: any;

export class LocalStorage {
	
	
	Datastore = require('nedb');
	db: any;
	
	dataBaseInfo: DataBaseInfo;
	employeeLoader: EmployeeLoader;
	
	constructor (dataFileName: string) {
		
		this.dataBaseInfo = new DataBaseInfo();
		this.db = new this.Datastore({ filename: 'datastore-employees', autoload: true });
		
		// initialize all of the loaders
		this.employeeLoader = new EmployeeLoader (this.db);
		// this.debugONLY_delAll();
		
		// retrieve information about the database.  Checks if last index exists, if not
		// then it adds that entry to the embedded database		
		var _this = this; // so the inline functions can get to the right "this"
		this.db.find({
			"dataBaseInfo": { $exists: true }
		},
			function (err, docs) {

				if (docs.length == 0) {
					// initialize and set all indices to zero
					console.log ("inserting lastAddedIndexObject")
					_this.dataBaseInfo.curIndexList = _this.dataBaseInfo.getEmptyIndexList();
					
					// and record in the local db
					_this.db.insert({dataBaseInfo: _this.dataBaseInfo});
				} else {
					// load up the stored lastIndex;
					if (docs.length > 1) {
						console.log("LocalStorage: Warning: DataInfo has more than 1 occurence.");
						// _this.delAll();
					} else {
						// grab the current index
						console.log ("Loading local storage database info entry");
						// _this.dataBaseInfo.lastAddedIndexObjects = docs[0].lastAddedIndexObjects;
						_this.dataBaseInfo.setIndices (docs[0].dataBaseInfo.curIndexList);
					}
				}
			});
	}
	
	addRecord (record: RecordDTO) {
		var recordType = record.getType();
		var object = record;
		var isSynced = record.isSynced();  // has to do with syncing with remote
		this.db.insert ({
			recordType: recordType,
			object: object,
			isSynced: isSynced
		});
	}
	
	delIndexObjects () {
		
	}
	
	debugONLY_delAll() {
		console.log ("debug only: deleting whole local storage db");
		this.db.remove({}, { multi: true }, function (err, docs) { });
	}
	
	debugONLY_showAll() {
		this.db.find({}, { }, function (err, docs) {
			console.log ("debugONLY_showAll: printing whole database contents:");
			console.log (docs);
		 });
	}
	
}