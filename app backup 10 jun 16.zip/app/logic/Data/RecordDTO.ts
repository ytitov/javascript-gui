export enum RecordType {
	Client,
	Employee,
	Appointment,
	Service,
	Product
}

export interface RecordDTO {
	/**
	 * field setter for the record
	 */
	fillObject (record: any) : any;
	getObject () : any; // gets you the actual object
	getType () : RecordType;
	isSynced () : boolean; // is it synced to remote
}