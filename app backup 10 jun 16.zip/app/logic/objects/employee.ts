import {Person} from './person';
import {UserGuiDTO} from './gui-dto/UserDTO';
import {RecordDTO, RecordType} from "../Data/RecordDTO";

export class Employee implements UserGuiDTO, RecordDTO {
	person: Person;
	
	// create empty
	constructor() {
		this.person = new Person("","","","","","","","","","","");
	}
	
	// UserGuiDTO interface functions
	getId () {
		return this.person.id;
	}
	
	getLabel() {
		return this.person.first + " " + this.person.last;
	}
	
	// RecordDTO interface functions
	getObject () : any {
		return {
			Employee: this
		}
	} // returns the object which is attached to the record
	getType () : RecordType {
		return RecordType.Employee;
	}
	
	isSynced () : boolean {
		// todo implement this
		return true;
	}
}