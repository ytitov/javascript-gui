export class Service {
	description: string;
	priceWholeNum: number;
	priceDecimal: number;
	unitSymbol: string;
	unitDescription: string;
	
	constructor (params: any) {
		this.description = params.description;
		this.priceWholeNum = params.priceWholeNum;
		this.priceDecimal = params.priceDecimal;
		this.unitSymbol = "$";
		this.unitDescription = params.unitDescription;
	}
}